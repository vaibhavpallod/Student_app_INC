package com.example.studentappinc;

public class StudentIDreturn {

    String JudgeID,evaluationdone;

    public StudentIDreturn(String JudgeID,String evaluationdone ) {
        this.JudgeID= JudgeID;
        this.evaluationdone=evaluationdone;
    }


    public String getJudgeid() {
        return JudgeID;
    }

    public String getEvaluationdone() {
        return evaluationdone;
    }







}
